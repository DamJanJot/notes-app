

<?php
$host = '81.171.31.232'; // Adres serwera bazy danych
$dbname = 'dj98'; // Nazwa bazy danych
$user = 'dj98'; // Nazwa użytkownika bazy danych
$pass = 'Nowehaslo7777'; // Hasło do bazy danych

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Błąd połączenia z bazą danych: " . $e->getMessage());
}
?>
